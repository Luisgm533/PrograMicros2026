/*
 * Proyecto2_Micros.c
 *
 * Author : luisg
 */ 

#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>

#include "ADC.h"
#include "SERVO_PWM.h"
#include "USART.h"
#include "EEPROM_APP.h"
#include "BUTTON.h"
#include "LEDS.h"

typedef enum
{
	MODO_MENU = 0,
	MODO_MANUAL,
	MODO_EEPROM,
	MODO_UART
} modo_t;

static modo_t modo_actual = MODO_MENU;

static uint16_t servo_pos[4] = {1500, 1500, 1500, 1500};

static uint16_t map_adc_to_us(uint16_t adc)
{
	return 1000 + ((uint32_t)adc * 1000) / 1023;
}

static void enviar_menu(void)
{
	USART_SendString("\r\n=== MENU PROYECTO 2 ===\r\n");
	USART_SendString("1. Modo Manual\r\n");
	USART_SendString("2. Modo EEPROM\r\n");
	USART_SendString("3. Modo UART\r\n");
	USART_SendString("Seleccione modo: ");
}

static void modo_manual(void)
{
	uint16_t adc0 = ADC_Read(0);
	uint16_t adc1 = ADC_Read(1);
	uint16_t adc2 = ADC_Read(2);
	uint16_t adc3 = ADC_Read(3);

	servo_pos[0] = map_adc_to_us(adc0);
	servo_pos[1] = map_adc_to_us(adc1);
	servo_pos[2] = map_adc_to_us(adc2);
	servo_pos[3] = map_adc_to_us(adc3);

	SERVO_Set_us(0, servo_pos[0]);
	SERVO_Set_us(1, servo_pos[1]);
	SERVO_Set_us(2, servo_pos[2]);
	SERVO_Set_us(3, servo_pos[3]);

	if (BUTTON_SavePressed())
	{
		EEPROM_SavePosition(servo_pos);
		USART_SendString("\r\nPosicion guardada en EEPROM\r\n");
		_delay_ms(300);
	}
}

static void modo_eeprom(void)
{
	uint8_t total = EEPROM_GetSavedCount();

	if (total == 0)
	{
		USART_SendString("\r\nNo hay posiciones guardadas\r\n");
		_delay_ms(1000);
		return;
	}

	for (uint8_t i = 0; i < total; i++)
	{
		EEPROM_ReadPosition(i, servo_pos);

		SERVO_Set_us(0, servo_pos[0]);
		SERVO_Set_us(1, servo_pos[1]);
		SERVO_Set_us(2, servo_pos[2]);
		SERVO_Set_us(3, servo_pos[3]);

		_delay_ms(800);
	}
}

static void modo_uart(void)
{
	char buffer[32];

	if (USART_ReadLine(buffer, sizeof(buffer)))
	{
		uint16_t s1, s2, s3, s4;

		if (USART_Parse4Values(buffer, &s1, &s2, &s3, &s4))
		{
			servo_pos[0] = s1;
			servo_pos[1] = s2;
			servo_pos[2] = s3;
			servo_pos[3] = s4;

			SERVO_Set_us(0, servo_pos[0]);
			SERVO_Set_us(1, servo_pos[1]);
			SERVO_Set_us(2, servo_pos[2]);
			SERVO_Set_us(3, servo_pos[3]);

			USART_SendString("Movimiento recibido\r\n");
		}
	}
}

int main(void)
{
	ADC_Init();
	SERVO_Init();
	USART_Init(9600);
	EEPROM_Init();
	BUTTON_Init();
	LEDS_Init();

	enviar_menu();

	while (1)
	{
		char dato;

		if (USART_ReadChar(&dato))
		{
			if (dato == '1')
			{
				modo_actual = MODO_MANUAL;
				LEDS_SetMode(LED_MODE_MANUAL);
				USART_SendString("\r\nModo Manual activo\r\n");
			}
			else if (dato == '2')
			{
				modo_actual = MODO_EEPROM;
				LEDS_SetMode(LED_MODE_EEPROM);
				USART_SendString("\r\nModo EEPROM activo\r\n");
			}
			else if (dato == '3')
			{
				modo_actual = MODO_UART;
				LEDS_SetMode(LED_MODE_UART);
				USART_SendString("\r\nModo UART activo\r\n");
				USART_SendString("Formato: 1000,1500,1200,1800\r\n");
			}
			else if (dato == 'm' || dato == 'M')
			{
				modo_actual = MODO_MENU;
				LEDS_AllOff();
				enviar_menu();
			}
		}

		if (modo_actual == MODO_MANUAL)
		{
			modo_manual();
		}
		else if (modo_actual == MODO_EEPROM)
		{
			modo_eeprom();
		}
		else if (modo_actual == MODO_UART)
		{
			modo_uart();
		}
	}
}